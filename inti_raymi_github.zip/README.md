# Inti Raymi — A Festa do Sol dos Incas

Site educativo de TCC sobre a história, os rituais e a celebração contemporânea do Inti Raymi.

## Arquivos

- `index.html`: estrutura e conteúdo do site.
- `style.css`: aparência, cores e adaptação para celulares.
- `script.js`: menu interativo, indicador de rolagem e botão para voltar ao início.

## Publicar no GitHub Pages

1. Entre em https://github.com e crie um repositório público, por exemplo `inti-raymi-tcc`.
2. Em **Add file → Upload files**, envie `index.html`, `style.css` e `script.js` para a raiz do repositório. Clique em **Commit changes**.
3. Acesse **Settings → Pages**. Em **Build and deployment**, selecione **Deploy from a branch**.
4. Escolha a branch `main` e a pasta `/ (root)` e clique em **Save**.
5. Aguarde a publicação. O endereço normalmente será `https://SEU-USUARIO.github.io/inti-raymi-tcc/`.

## Antes de entregar

- Substitua `[NOME DO ALUNO]` e `[INSTITUIÇÃO]` no `index.html`.
- Confira as referências, personalize a metodologia e inclua os resultados reais do TCC.
- As fotografias são carregadas de fontes externas: confira licenças e créditos antes de publicar.
- Verifique se o vídeo indicado está disponível.
- Teste o site no computador e no celular.

## Google Sites

Depois de publicar, no Google Sites selecione **Inserir → Incorporar → URL** e cole o endereço do GitHub Pages. Também é possível adicionar um botão que abra o site publicado.
